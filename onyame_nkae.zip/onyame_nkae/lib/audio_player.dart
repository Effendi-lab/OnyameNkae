import 'package:assets_audio_player/assets_audio_player.dart';

mmoaAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Mmoa1_O_me_Nyankopɔn.mp3");
  assetsAudioPlayer.play();
}
mmoaAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Mmoa1_O_me_Nyankopɔn.mp3");
  assetsAudioPlayer.stop();
}



mmoa2AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Mmoa2_Awurade.mp3");
  assetsAudioPlayer.play();
}
mmoa2AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Mmoa2_Awurade.mp3");
  assetsAudioPlayer.stop();
}

sohweBere1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/SɔhwɛBere1_So_Obi.mp3");
  assetsAudioPlayer.play();
}
sohweBere1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/SɔhwɛBere1_So_Obi.mp3");
  assetsAudioPlayer.stop();
}

sohweBere2AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/SɔhwɛBere2_O_Awurade.mp3");
  assetsAudioPlayer.play();
}
sohweBere2AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/SɔhwɛBere2_O_Awurade.mp3");
  assetsAudioPlayer.stop();
}

sohweBere3AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/SɔhwɛBere3_O_Awurade.mp3");
  assetsAudioPlayer.play();
}
sohweBere3AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/SɔhwɛBere3_O_Awurade.mp3");
  assetsAudioPlayer.stop();
}

sohweBere4AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/SɔhwɛBere4_Ɔno_ne_Ahummɔbɔ_no.mp3");
  assetsAudioPlayer.play();
}
sohweBere4AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/SɔhwɛBere4_Ɔno_ne_Ahummɔbɔ_no.mp3");
  assetsAudioPlayer.stop();
}

annwummere1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Annwummere1_O_me_Nyankopɔn.mp3");
  assetsAudioPlayer.play();
}
annwummere1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Annwummere1_O_me_Nyankopɔn.mp3");
  assetsAudioPlayer.stop();
}


abusua1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Abusua1_O_me_Nyankopɔn.mp3");
  assetsAudioPlayer.play();
}
abusua1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Abusua1_O_me_Nyankopɔn.mp3");
  assetsAudioPlayer.stop();
}


abusua2AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Abusua2_Mawurade.mp3");
  assetsAudioPlayer.play();
}
abusua2AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Abusua2_Mawurade.mp3");
  assetsAudioPlayer.stop();
}

awofo1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Awofo1_Mebisa.mp3");
  assetsAudioPlayer.play();
}

awofo1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Awofo1_Mebisa.mp3");
  assetsAudioPlayer.stop();
}

kununom1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Kununom1_O_Nyankopɔn.mp3");
  assetsAudioPlayer.play();
}
kununom1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Kununom1_O_Nyankopɔn.mp3");
  assetsAudioPlayer.stop();
}


apamNoMuDenye1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/ApamNoMuDenyɛ1_O_Awurade.mp3");
  assetsAudioPlayer.play();
}
apamNoMuDenye1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/ApamNoMuDenyɛ1_O_Awurade.mp3");
  assetsAudioPlayer.stop();
}


ahohyeso1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Ahohyɛso1_Anuonyam_nka_Wo.mp3");
  assetsAudioPlayer.play();
}
ahohyeso1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Ahohyɛso1_Anuonyam_nka_Wo.mp3");
  assetsAudioPlayer.stop();
}


bonefafiri1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Bɔnefafiri1_Ayeyi_nka_Wo.mp3");
  assetsAudioPlayer.play();
}
bonefafiri1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Bɔnefafiri1_Ayeyi_nka_Wo.mp3");
  assetsAudioPlayer.stop();
}


ayaresa1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Ayaresa1_Wo_Din.mp3");
  assetsAudioPlayer.play();
}
ayaresa1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Ayaresa1_Wo_Din.mp3");
  assetsAudioPlayer.stop();
}


adasamma1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Adasama1_O_Awurade.mp3");
  assetsAudioPlayer.play();
}
adasamma1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Adasama1_O_Awurade.mp3");
  assetsAudioPlayer.stop();
}

nhyiam1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Nhyiam1_O_honhom.mp3");
  assetsAudioPlayer.play();
}

nhyiam1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Nhyiam1_O_honhom.mp3");
  assetsAudioPlayer.stop();
}


nhyiam2AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Nhyiam2_O_Onyankopɔn.mp3");
  assetsAudioPlayer.play();
}

nhyiam2AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Nhyiam2_O_Onyankopɔn.mp3");
  assetsAudioPlayer.stop();
}


honhommunhyiam1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HonhomMuNhyiam1_O_Ɔsoro_Hene.mp3");
  assetsAudioPlayer.play();
}
honhommunhyiam1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HonhomMuNhyiam1_O_Ɔsoro_Hene.mp3");
  assetsAudioPlayer.stop();
}


honhomMuDenhye1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HonhomMuDenhyɛ1_O_me_Nyankopɔn.mp3");
  assetsAudioPlayer.play();
}
honhomMuDenhye1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HonhomMuDenhyɛ1_O_me_Nyankopɔn.mp3");
  assetsAudioPlayer.stop();
}


honhomMuDenhye2AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HonhomMuDenhyɛ2_O_Onyankopɔn.mp3");
  assetsAudioPlayer.play();
}
honhomMuDenhye2AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HonhomMuDenhyɛ2_O_Onyankopɔn.mp3");
  assetsAudioPlayer.stop();
}


osomNoNkonimdi1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/ƆsomNoNkonimdi1_O_Awurade.mp3");
  assetsAudioPlayer.play();
}
osomNoNkonimdi1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/ƆsomNoNkonimdi1_O_Awurade.mp3");
  assetsAudioPlayer.stop();
}


sohweNeAhokyereBere1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/SɔhwɛNeAhokyereBere1_Anuonyam_nka_Wo.mp3");
  assetsAudioPlayer.play();
}
sohweNeAhokyereBere1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/SɔhwɛNeAhokyereBere1_Anuonyam_nka_Wo.mp3");
  assetsAudioPlayer.stop();
}


nkabom1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Nkabom1_O_me_Nyankopɔn.mp3");
  assetsAudioPlayer.play();
}
nkabom1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Nkabom1_O_me_Nyankopɔn.mp3");
  assetsAudioPlayer.stop();
}


denye1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Denyɛ1_O_Ayeyi_ne_anuonyam.mp3");
  assetsAudioPlayer.play();
}
denye1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Denyɛ1_O_Ayeyi_ne_anuonyam.mp3");
  assetsAudioPlayer.stop();
}


denye2AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Denyɛ2_O_Awurade.mp3");
  assetsAudioPlayer.play();
}
denye2AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Denyɛ2_O_Awurade.mp3");
  assetsAudioPlayer.stop();
}


ahopakyi1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Ahopakyi1_O_Awurade.mp3");
  assetsAudioPlayer.play();
}
ahopakyi1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Ahopakyi1_O_Awurade.mp3");
  assetsAudioPlayer.stop();
}


anopa1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Anɔpa_Masɔre_anɔpa_yi.mp3");
  assetsAudioPlayer.play();
}
anopa1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Anɔpa_Masɔre_anɔpa_yi.mp3");
  assetsAudioPlayer.stop();
}


nkanfoNeAyeyi1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/NkanfoNeAyeyi1_O_Awurade.mp3");
  assetsAudioPlayer.play();
}
nkanfoNeAyeyi1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/NkanfoNeAyeyi1_O_Awurade.mp3");
  assetsAudioPlayer.stop();
}


nkanfoNeAyeyi2AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/NkanfoNeAyeyi2_Ayeyi_nka_Wo.mp3");
  assetsAudioPlayer.play();
}
nkanfoNeAyeyi2AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/NkanfoNeAyeyi2_Ayeyi_nka_Wo.mp3");
  assetsAudioPlayer.stop();
}


banbo1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Banbɔ1_Wɔ_Otumfo_Nyankopɔn.mp3");
  assetsAudioPlayer.play();
}
banbo1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Banbɔ1_Wɔ_Otumfo_Nyankopɔn.mp3");
  assetsAudioPlayer.stop();
}


banbo2AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Banbɔ2_O_mAwurade.mp3");
  assetsAudioPlayer.play();
}
banbo2AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Banbɔ2_O_mAwurade.mp3");
  assetsAudioPlayer.stop();
}

banbo3AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Banbɔ3_O_Nyankopɔn.mp3");
  assetsAudioPlayer.play();
}
banbo3AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Banbɔ3_O_Nyankopɔn.mp3");
  assetsAudioPlayer.stop();
}


awufoMpae1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/MpaeAWɔbɔMaAwufo1_Anuonyam_nka_Wo.mp3");
  assetsAudioPlayer.play();
}
awufoMpae1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/MpaeAWɔbɔMaAwufo1_Anuonyam_nka_Wo.mp3");
  assetsAudioPlayer.stop();
}

ahokyere1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Ahokyere1_Nea_wo_de.mp3");
  assetsAudioPlayer.play();
}
ahokyere1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Ahokyere1_Nea_wo_de.mp3");
  assetsAudioPlayer.stop();
}


ahokyere2AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Ahokyere2_O_Nyankopɔn.mp3");
  assetsAudioPlayer.play();
}
ahokyere2AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Ahokyere2_O_Nyankopɔn.mp3");
  assetsAudioPlayer.stop();
}


ohyeMpaeNnianimAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/ƆhyɛMpae_Nnianim.mp3");
  assetsAudioPlayer.play();
}
ohyeMpaeNnianimAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/ƆhyɛMpae_Nnianim.mp3");
  assetsAudioPlayer.stop();
}
ohyeMpaeTiatiaAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/ƆhyɛMpae_Tiatia.mp3");
  assetsAudioPlayer.play();
}

ohyeMpaeTiatiaAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/ƆhyɛMpae_Tiatia.mp3");
  assetsAudioPlayer.stop();
}
ohyeMpaeAdatamAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/ƆhyɛMpae_Adatam.mp3");
  assetsAudioPlayer.play();
}
ohyeMpaeAdatamAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/ƆhyɛMpae_Adatam.mp3");
  assetsAudioPlayer.stop();
}

ohyeMpaeTentenAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/ƆhyɛMpae_Tenten.mp3");
  assetsAudioPlayer.play();
}
ohyeMpaeTentenAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/ƆhyɛMpae_Tenten.mp3");
  assetsAudioPlayer.stop();
}


ahmadAdansePonNoAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/AhmadAdansePonNo.mp3");
  assetsAudioPlayer.play();
}

ahmadAdansePonNoAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/AhmadAdansePonNo.mp3");
  assetsAudioPlayer.stop();
}
nsraMpaeBahaullahAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/NsraMpae_Bahaullah_ne_Bab_de_no.mp3");
  assetsAudioPlayer.play();
}
nsraMpaeBahaullahAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/NsraMpae_Bahaullah_ne_Bab_de_no.mp3");
  assetsAudioPlayer.stop();
}
nsraMpaeAbdulBahaAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/NsraMpae_Abdul-Baha_de_no.mp3");
  assetsAudioPlayer.play();
}
nsraMpaeAbdulBahaAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/NsraMpae_Abdul-Baha_de_no.mp3");
  assetsAudioPlayer.stop();
}

akonkye1AudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Akɔnkye1_Ayeyi_nka_Wo.mp3");
  assetsAudioPlayer.play();
}
akonkye1AudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/Akɔnkye1_Ayeyi_nka_Wo.mp3");
  assetsAudioPlayer.stop();
}
ayaresaMpaeTentenAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/AyaresaMpaeTenten.mp3");
  assetsAudioPlayer.play();
}
ayaresaMpaeTentenAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/AyaresaMpaeTenten.mp3");
  assetsAudioPlayer.stop();
}

oHonhomBaMafotusemAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OHonhomBa_MafotusɛmAEdiKanNi.mp3");
  assetsAudioPlayer.play();
}
oHonhomBaMafotusemAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OHonhomBa_MafotusɛmAEdiKanNi.mp3");
  assetsAudioPlayer.stop();
}
oAbodeBaDoMeAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OAbɔdeBa_DɔMe.mp3");
  assetsAudioPlayer.play();
}
oAbodeBaDoMeAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OAbɔdeBa_DɔMe.mp3");
  assetsAudioPlayer.stop();
}

oAbodeBaWoParadiseAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OAbɔdeBa_WoParadiseNeMeDɔ.mp3");
  assetsAudioPlayer.play();
}
oAbodeBaWoParadiseAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OAbɔdeBa_WoParadiseNeMeDɔ.mp3");
  assetsAudioPlayer.stop();
}
oNipaBaSeWoDoMeAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_SɛWoDɔMe.mp3");
  assetsAudioPlayer.play();
}
oNipaBaSeWoDoMeAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_SɛWoDɔMe.mp3");
  assetsAudioPlayer.stop();
}
oAbodeBaMeDoNeMahodenAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OAbɔdeBa_MeDɔNeMahoɔden.mp3");
  assetsAudioPlayer.play();
}
oAbodeBaMeDoNeMahodenAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OAbɔdeBa_MeDɔNeMahoɔden.mp3");
  assetsAudioPlayer.stop();
}
oOkasaBaWoNeMahodenAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OƆkasaBa_WoNeMahoɔden.mp3");
  assetsAudioPlayer.play();
}
oOkasaBaWoNeMahodenAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OƆkasaBa_WoNeMahoɔden.mp3");
  assetsAudioPlayer.stop();
}

oAbodeBaWoyeMeKaneaAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OAbɔdeBa_WoYɛMeKanea.mp3");
  assetsAudioPlayer.play();
}
oAbodeBaWoyeMeKaneaAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OAbɔdeBa_WoYɛMeKanea.mp3");
  assetsAudioPlayer.stop();
}

oHannBaMaWoWereMfiAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OHannBa_MaWoWerɛMfi.mp3");
  assetsAudioPlayer.play();
}
oHannBaMaWoWereMfiAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OHannBa_MaWoWerɛMfi.mp3");
  assetsAudioPlayer.stop();
}

oNipaBaMaMeNsomWoBoAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_MaMeNsomWoBo.mp3");
  assetsAudioPlayer.play();
}
oNipaBaMaMeNsomWoBoAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_MaMeNsomWoBo.mp3");
  assetsAudioPlayer.stop();
}
oHonhomBaMaboWoAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OHonhomBa_MabɔWoAnuonyamMu.mp3");
  assetsAudioPlayer.play();
}
oHonhomBaMaboWoAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OHonhomBa_MabɔWoAnuonyamMu.mp3");
  assetsAudioPlayer.stop();
}

oAbodeBaEdenNaWomaWoWereAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OAbɔdeBa_ƐdenNaWomaWoWerɛ.mp3");
  assetsAudioPlayer.play();
}
oAbodeBaEdenNaWomaWoWereAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OAbɔdeBa_ƐdenNaWomaWoWerɛ.mp3");
  assetsAudioPlayer.stop();
}

oNipaBaBereAWoAnkasaAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_BereAWoAnkasa.mp3");
  assetsAudioPlayer.play();
}
oNipaBaBereAWoAnkasaAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_BereAWoAnkasa.mp3");
  assetsAudioPlayer.stop();
}
oHonhomBaHuSeNokwareAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OHonhomBa_HuSɛNokwareMu.mp3");
  assetsAudioPlayer.play();
}
oHonhomBaHuSeNokwareAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OHonhomBa_HuSɛNokwareMu.mp3");
  assetsAudioPlayer.stop();
}

oAbodeBaNkaNkyereOkraAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OAbɔdeBa_NkaNKyerɛƆkra.mp3");
  assetsAudioPlayer.play();
}
oAbodeBaNkaNkyereOkraAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OAbɔdeBa_NkaNKyerɛƆkra.mp3");
  assetsAudioPlayer.stop();
}

oNipaBaSeMakoaBiAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_SɛMakoaBi.mp3");
  assetsAudioPlayer.play();
}
oNipaBaSeMakoaBiAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_SɛMakoaBi.mp3");
  assetsAudioPlayer.stop();
}

oAbodeBaBuWabraboAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OAbɔdeBa_BuWabrabɔHoAkontaa.mp3");
  assetsAudioPlayer.play();
}
oAbodeBaBuWabraboAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OAbɔdeBa_BuWabrabɔHoAkontaa.mp3");
  assetsAudioPlayer.stop();
}

oOtumfoNoBaMayeOwuoAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OOtumfoNoBa_MayɛOwuƆsomafo.mp3");
  assetsAudioPlayer.play();
}
oOtumfoNoBaMayeOwuoAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OOtumfoNoBa_MayɛOwuƆsomafo.mp3");
  assetsAudioPlayer.stop();
}

oNipaBaMmaWoWereNhowAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_MmaWoWerɛNhow.mp3");
  assetsAudioPlayer.play();
}
oNipaBaMmaWoWereNhowAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_MmaWoWerɛNhow.mp3");
  assetsAudioPlayer.stop();
}

oNipaBaDiAhurusiAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_DiAhurusi.mp3");
  assetsAudioPlayer.play();
}
oNipaBaDiAhurusiAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_DiAhurusi.mp3");
  assetsAudioPlayer.stop();
}

oNipaBaNyiMatadeAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_NyiMatadeFɛfɛɛfɛNo.mp3");
  assetsAudioPlayer.play();
}
oNipaBaNyiMatadeAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_NyiMatadeFɛfɛɛfɛNo.mp3");
  assetsAudioPlayer.stop();
}

oAbodeBaNantewAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OAbɔdeBa_NantewWɔMeMmaransɛmMu.mp3");
  assetsAudioPlayer.play();
}

oAbodeBaNantewAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/OAbɔdeBa_NantewWɔMeMmaransɛmMu.mp3");
  assetsAudioPlayer.stop();
}

oNipaBaNtowAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_NtowMeMmaransɛmNKyene.mp3");
  assetsAudioPlayer.play();
}

oNipaBaNtowAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_NtowMeMmaransɛmNKyene.mp3");
  assetsAudioPlayer.stop();
}

oNipaBaSeWotuFaWimAudioPlay(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_SɛWotuFaWim.mp3");
  assetsAudioPlayer.play();
}
oNipaBaSeWotuFaWimAudioStop(){
  final assetsAudioPlayer =  AssetsAudioPlayer();
  assetsAudioPlayer.open("audios/HiddenWordsAudio/ONipaBa_SɛWotuFaWim.mp3");
  assetsAudioPlayer.stop();
}